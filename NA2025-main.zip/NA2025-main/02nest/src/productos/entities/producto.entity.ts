export class Producto {
  /*public id: string;
  public nombre: string;
  public descripcion?: string;
  public precio: number;/*/

  constructor(
    id: string,
    nombre: string,
    descripcion: string,
    precio: number,
  ) {}
}
